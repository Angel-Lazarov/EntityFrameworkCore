﻿namespace Medicines.Data
{
    public static class DataConstrains
    {
        public const string MedicinePriceMinValue = "0.01";
        public const string MedicinePriceMaxValue = "1000.00";
    }
}
