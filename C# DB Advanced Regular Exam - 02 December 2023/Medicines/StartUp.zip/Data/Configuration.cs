﻿namespace Medicines.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=Medicines;User Id = sa;Password = SoftUn!2021; TrustServerCertificate=True;";

    }
}
