﻿namespace Trucks.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=Trucks;User Id=sa;Password=SoftUn!2021;TrustServerCertificate=True;";
    }
}