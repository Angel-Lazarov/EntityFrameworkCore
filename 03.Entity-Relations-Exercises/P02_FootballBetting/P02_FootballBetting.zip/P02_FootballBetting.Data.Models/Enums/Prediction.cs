﻿namespace P02_FootballBetting.Data.Models.Enums;

public enum Prediction
{
    Win,
    Lose,
    Draw
}
