﻿namespace P02_FootballBetting;

public class StartUp
{
    static void Main()
    {
        //Console.WriteLine("Hello, World!");

        //FootballBettingContext context = new FootballBettingContext();

        //FootballBettingContext contex = new FootballBettingContext();



    }

}
