﻿namespace Trucks.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=192.168.88.40 ,1434;Database=Trucks;User Id = sa; Password = password;";
    }
}