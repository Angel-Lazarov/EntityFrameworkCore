﻿namespace MusicHub.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=.;Database=MusicHub;User Id = sa;Password = SoftUn!2021; TrustServerCertificate=True;";

        //"Server =.;Database = FootballBookmakerSystem;User Id = sa;Password = SoftUn!2021; TrustServerCertificate=True;"
    }
}
