﻿namespace MusicHub.Data.Models.Enums;
public enum Genre
{
    Blues,
    Rap,
    PopMusic,
    Rock,
    Jazz
}
