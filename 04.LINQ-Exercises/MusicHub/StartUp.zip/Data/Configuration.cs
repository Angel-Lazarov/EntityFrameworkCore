﻿namespace MusicHub.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=192.168.88.40 ,1434;Database=MusicHub;User Id = sa; Password = password;";
    }
}
